# Forex Scanner Android

This is a starter Android WebView app with a dark scanner dashboard.

## Build the APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open **Actions** → **Build APK** → **Run workflow**.
3. Wait for the workflow to finish successfully.
4. Open the completed run and download the **ForexScanner-apk** artifact.
5. Extract the ZIP to get `app-debug.apk`, then transfer it to your Android phone and install it.

## Important
The current app is a UI prototype. Prices are illustrative and scanner statuses are placeholders. It does **not** yet connect to a broker, live price feed, push notification service, or calculate validated trading signals. Those require a selected data provider and implementation/testing before live use.
